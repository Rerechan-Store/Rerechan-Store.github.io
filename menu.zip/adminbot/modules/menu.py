import subprocess
import requests
from telethon import events, Button
from adminbot import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline(" SSH OVPN MANAGER ", "ssh")],
        [Button.inline(" VMESS MANAGER ", "vmess"),
         Button.inline(" VLESS MANAGER ", "vless")],
        [Button.inline(" TROJAN MANAGER ", "trojan")],
        [Button.url("WHATSAP", "https://wa.me/6283120684925"),
         Button.url("ORDER SCRIPT", "https://t.me/Rerechan02")]
    ]
    ox = requests.get("https://ipv4.icanhazip.com").text.strip()
    bz = f"curl -sS https://raw.githubusercontent.com/Rerechan-Store/iziznscript/main/ip | grep '{ox}' | cut -d ' ' -f3"
    bo = subprocess.check_output(bz, shell=True).decode("ascii").strip()
    if ox != bo:
        sender = await event.get_sender()
        val = valid(str(sender.id))
        if val == "false":
            try:
                await event.answer("Akses Ditolak", alert=True)
            except:
                await event.reply("Akses Ditolak")
        elif val == "true":
            sdss = "cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
            namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
            hap = subprocess.call(["systemctl", "is-active", "--quiet", "haproxy"])
            if hap == 0:
                hap1 = '🟢'
            else:
                hap1 = '🔴'
            ngx = subprocess.call(["systemctl", "is-active", "--quiet", "nginx"])
            if ngx == 0:
                ngx1 = '🟢'
            else:
                ngx1 = '🔴'
            xr = subprocess.call(["systemctl", "is-active", "--quiet", "xray"])
            if xr == 0:
                xr1 = '🟢'
            else:
                xr1 = '🔴'
            sh = subprocess.call(["systemctl", "is-active", "--quiet", "ws"])
            if sh == 0:
                ws1 = '🟢'
            else:
                ws1 = '🔴'
            msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**  ◇☘️ ADMIN PANEL BOT ☘️◇**
━━━━━━━━━━━━━━━━━━━━━━━**

 **» OS     :** `{namaos.strip().replace('"','')}`**

**              --~~ Service Status~~--**
**  HAPROXY  :**  `{hap1}`  ** XRAY         :**  `{xr1}`
**  NGINX         :**  `{ngx1}` **  WS EPRO :**  `{ws1}`
━━━━━━━━━━━━━━━━━━━━━━━
** Bot By @fn_project **
━━━━━━━━━━━━━━━━━━━━━━━
"""
            x = await event.edit(msg, buttons=inline)
            if not x:
                await event.reply(msg, buttons=inline)
    else:
        await event.respond("** You Dont Have Access**")