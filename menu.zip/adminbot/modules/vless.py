import subprocess
import requests
import re
import datetime
from telethon import events, Button
from adminbot import *

@bot.on(events.CallbackQuery(data=b'create-vless'))
async def create_vless(event):
    async def create_vless_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username:**')
            user = await user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user.raw_text
        async with bot.conversation(chat) as exp:
            await event.respond("**Choose Expiry Day**", buttons=[
                [Button.inline(" 3 Day ", "3"),
                 Button.inline(" 7 Day ", "7")],
                [Button.inline(" 30 Day ", "30"),
                 Button.inline(" 60 Day ", "60")]
            ])
            exp = await exp.wait_event(events.CallbackQuery)
            exp = exp.data.decode("ascii")
        await event.edit("`Wait.. Setting up an Account`")
        cmd = f'printf "%s\n" "{user}" "{exp}" | add-vless'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError as e:
            await event.respond("**User Already Exist**")
        else:
            today = datetime.date.today()
            later = today + datetime.timedelta(days=int(exp))
            x = re.findall("vless://(.*)", a)
            uuid = re.search("vless://(.*?)@", x[0]).group(1)
            msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**⟨ Xray/Vless Account ⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Remarks     :** `{user}`
**» Host Server :** `{DOMAIN}`
**» port TLS    :** `443`
**» Port NTLS   :** `80`
**» NetWork     :** `(WS) or (gRPC)`
**» User ID     :** `{uuid}`
**» Path Vless  :** `/vlessws`
**» Path Dynamic:** `http://BUG.COM/vless`
**◇━━━━━━━━━━━━━━━━━◇**
**» Link TLS   : **
`{x[0]}`
**◇━━━━━━━━━━━━━━━━━◇**
**» Link NTLS  :**
`{x[1].replace(" ","")}`
**◇━━━━━━━━━━━━━━━━━◇**
**» Link GRPC  :**
`{x[2].replace(" ","")}`
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await create_vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'delete-vless'))
async def delete_vless(event):
    async def delete_vless_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username:**')
            user = await user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user.raw_text
        cmd = f'printf "%s\n" "{user}" | del-vless'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError as e:
            await event.respond("**User Not Found**")
        else:
            msg = f"""**Successfully Deleted**"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await delete_vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'vless'))
async def vless(event):
    async def vless_(event):
        inline = [
            [Button.inline(" CREATE VLESS ", "create-vless"),
             Button.inline(" DELETE VLESS ", "delete-vless")],
            [Button.inline("‹ Main Menu ›", "menu")]
        ]
        z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**     ◇☘️⟨ VLESS MANAGER ⟩☘️◇**
**◇━━━━━━━━━━━━━━━━━◇**
** 🔰 Service:** `VLESS`
** 🔰 Hostname/IP:** `{DOMAIN}`
** 🔰 ISP:** `{z["isp"]}`
** 🔰 Country:** `{z["country"]}`
**◇━━━━━━━━━━━━━━━━━◇**
"""
        await event.edit(msg, buttons=inline)

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await vless_(event)
    else:
        await event.answer("Access Denied", alert=True)